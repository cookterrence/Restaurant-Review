package com.powerReviews.springboot.web.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Service;

import com.powerReviews.springboot.web.model.Review;

@Service
public class ReviewService {

	
	

	private static List<Review> reviews = new ArrayList<Review>();
	private static int ReviewCount = 5;

	static {
		reviews.add(new Review(1, "terry", "yeah", new Date(), true));
		reviews.add(new Review(2, "Brett", "I waited a long time for my food and decided to just leave!", new Date(),
				false));
		reviews.add(new Review(3, "Jennifer", "Had a great time here, they made my aniversarry dinner special.",
				new Date(), true));
		reviews.add(new Review(4, "Adam", "The deserts are amazing!", new Date(), true));
		reviews.add(new Review(5, "Batman",
				"Had a LOT of family visit from out of town and the were extremly accomadating.", new Date(), true));
	}

	public List<Review> returnReview(String user) {
		List<Review> filteredReviews = new ArrayList<Review>();
		for (Review review : reviews) {
			if (review.getUser().equalsIgnoreCase(user)) {
				filteredReviews.add(review);
			}
		}
		return filteredReviews;
	}

	public Review retrieveReviews(int id) {
		for (Review review : reviews) {
			if (review.getId() == id) {
				return review;
			}
		}
		return null;
	}

	public void updateReview(Review review) {
		reviews.remove(review);
		reviews.add(review);
	}

	public void addReview(int id, String name, String desc, Date DateVisited, boolean visitAgain) {
		reviews.add(new Review(++ReviewCount, name, desc, DateVisited, visitAgain));
	}

	public void deleteReview(int id) {
		Iterator<Review> iterator = reviews.iterator();
		while (iterator.hasNext()) {
			Review review = iterator.next();
			if (review.getId() == id) {
				iterator.remove();
			}
		}
	}

	
}