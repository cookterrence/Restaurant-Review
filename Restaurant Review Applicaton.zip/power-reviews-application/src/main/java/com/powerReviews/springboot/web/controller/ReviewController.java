package com.powerReviews.springboot.web.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.powerReviews.springboot.web.model.Review;
import com.powerReviews.springboot.web.service.ReviewService;

@Controller
@SessionAttributes("name")
public class ReviewController {

	@Autowired
	ReviewService service;
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {

		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, false));
	}

	@RequestMapping(value = "/list-reviews", method = RequestMethod.GET)
	public String showReviews(ModelMap model) {
		String name = getLoggedInUserName(model);
		model.put("reviews", service.returnReview(name));

		return "list-reviews";

	}

	private String getLoggedInUserName(ModelMap model) {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		if (principal instanceof UserDetails) {
			return ((UserDetails) principal).getUsername();
		}

		return principal.toString();
	}

	@RequestMapping(value = "/add-review", method = RequestMethod.GET)
	public String showAddReivewPage(ModelMap model) {
		model.addAttribute("review",
				new Review(0, getLoggedInUserName(model), "Type your review here!", new Date(), new Boolean(null)));

		return "review";
	}

	@RequestMapping(value = "/add-review", method = RequestMethod.POST)
	public String addReview(ModelMap model, @Valid Review review, BindingResult result) {

		if (result.hasErrors()) {
			return "review";
		}

		service.addReview(0, getLoggedInUserName(model), review.getDesc(), review.getDateVisited(), new Boolean(null));
		return "redirect:/list-reviews";
	}

	@RequestMapping(value = "/update-review", method = RequestMethod.GET)
	public String showUpdateReviewPage(@RequestParam int id, ModelMap model) {

		Review review = service.retrieveReviews(id);
		model.put("review", review);
		return "review";

	}

	@RequestMapping(value = "/update-review", method = RequestMethod.POST)
	public String updateReview(ModelMap model, @Valid Review review, BindingResult result) {

		if (result.hasErrors()) {
			return "review";
		}

		review.setUser(getLoggedInUserName(model));

		service.updateReview(review);

		return "redirect:/list-reviews";

	}

	@RequestMapping(value = "/delete-review", method = RequestMethod.GET)
	public String deleteReview(@RequestParam int id) {

		if (id == 1)
			throw new RuntimeException("Something went wrong please contact support.");

		service.deleteReview(id);
		return "redirect:/list-reviews";
	}
}


