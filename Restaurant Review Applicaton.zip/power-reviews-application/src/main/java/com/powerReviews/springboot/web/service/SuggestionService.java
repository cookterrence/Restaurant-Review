package com.powerReviews.springboot.web.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.powerReviews.springboot.web.model.Suggestion;


@Service
public class SuggestionService {
public String suggestion;



	private static List<Suggestion> suggestions = new ArrayList<Suggestion>();
	private static int SuggestionCount = 5;
	
	public void addSuggestions(int id, String user, String reccomend) {
		suggestions.add(new Suggestion(++SuggestionCount, user, reccomend ));
	

	}
	public List<Suggestion> returnSuggestions(String user) {
		List<Suggestion> newSuggestions = new ArrayList<Suggestion>();
		for (Suggestion suggestion : suggestions) {
			newSuggestions.add(suggestion);
			}
		
		return newSuggestions;
	}
	public Suggestion retrieveSuggsetions(int id) {
		for(Suggestion suggestion : suggestions) {
			if(suggestion.getId() == id) {
				return suggestion;
			}
			
		}
		return null;
	}
	public void updateSuggestion(Suggestion suggestion) {
		suggestions.remove(suggestion);
		suggestions.add(suggestion);
	}
	
	
}

