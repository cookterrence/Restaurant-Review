package com.powerReviews.springboot.web.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestParam;

import com.powerReviews.springboot.web.model.Suggestion;
import com.powerReviews.springboot.web.service.SuggestionService;

@Controller
@SessionAttributes("name")

public class SuggestionController {
	@Autowired
	SuggestionService service;

	@RequestMapping(value = "/list-suggestions", method = RequestMethod.GET)
	public String showSuggestions(ModelMap model) {
		String name = getLoggedInUserName(model);
		model.put("suggestions", service.returnSuggestions(name));

		return "list-suggestions";

	}

	private String getLoggedInUserName(ModelMap model) {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		if (principal instanceof UserDetails) {
			return ((UserDetails) principal).getUsername();
		}

		return principal.toString();
	}

	@RequestMapping(value = "/add-suggestion", method = RequestMethod.GET)
	public String showAddSuggsetionPage(ModelMap model) {
		model.addAttribute("suggestion", new Suggestion(0, getLoggedInUserName(model), "Type your Suggestion here!"));

		return "suggestion";
	}

	@RequestMapping(value = "/add-suggestion", method = RequestMethod.POST)
	public String addSuggestion(ModelMap model, @Valid Suggestion suggestion, BindingResult result) {

		if (result.hasErrors()) {
			return "suggestion";
		}

		service.addSuggestions(0, getLoggedInUserName(model), suggestion.getRecommend());
		return "redirect:/list-suggestions";
	}

	@RequestMapping(value = "/update-suggestion", method = RequestMethod.GET)
	public String showUpdateSuggsetionPage(@RequestParam int id, ModelMap model) {

		Suggestion suggestion = service.retrieveSuggsetions(id);
		model.put("suggestion", suggestion);
		return "suggestion";

	}

	@RequestMapping(value = "/update-suggestion", method = RequestMethod.POST)
	public String updateSuggestion(ModelMap model, @Valid Suggestion Suggestion, BindingResult result) {

		if (result.hasErrors()) {
			return "suggestion";
		}

		Suggestion.setUser(getLoggedInUserName(model));

		service.updateSuggestion(Suggestion);

		return "redirect:/list-suggestions";

	}
}
