package com.powerReviews.springboot.web.model;

import java.util.Date;

public class Suggestion {

	private String recommend;
	private int id;
	private String user;
	
	
	
	public Suggestion() {
		super();
	}
	
	 public Suggestion(int id, String user, String recommend) {
	        super();
	        this.id = id;
	        this.recommend = recommend;
	        this.user = user;
	        
	        
	    }

	public String getRecommend() {
		return recommend;
	}

	public void setRecommend(String recommend) {
		this.recommend = recommend;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}
	@Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Suggestion other = (Suggestion) obj;
        if (id != other.id) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return String.format(
                "Review [id=%s,user=%s, recommend=%s]", id,
                user, recommend);
    }
	
	
}
