package com.powerReviews.springboot.web.model;

import java.util.Date;


import javax.validation.constraints.Size;


public class Review {

		
		private int id;
		private String user;
		
		@Size(min=10, message="Enter at least 10 Characters...")
		private String desc;
		private Date dateVisited;
		private boolean visitAgain;
		
		
		
		
		 public Review() {
	 		super();
	 }
		 
		 public Review(int id, String user, String desc, Date dateVisited,
		            boolean visitAgain) {
		        super();
		        this.id = id;
		        this.user = user;
		        this.desc = desc;
		        this.dateVisited =dateVisited;
		        this.visitAgain = visitAgain;
		        
		    }

		public Date getDateVisited() {
			return dateVisited;
		}

		public void setDateVisited(Date dateVisited) {
			this.dateVisited = dateVisited;
		}

		public boolean isVisitAgain() {
			return visitAgain;
		}

		public void setVisitAgain(boolean visitAgain) {
			this.visitAgain = visitAgain;
		}

		public String getDesc() {
			return desc;
		}

		public void setDesc(String desc) {
			this.desc = desc;
		}

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getUser() {
			return user;
		}

		public void setUser(String user) {
			this.user = user;
		}
		 
		 

		@Override
		    public boolean equals(Object obj) {
		        if (this == obj) {
		            return true;
		        }
		        if (obj == null) {
		            return false;
		        }
		        if (getClass() != obj.getClass()) {
		            return false;
		        }
		        Review other = (Review) obj;
		        if (id != other.id) {
		            return false;
		        }
		        return true;
		    }

		    @Override
		    public String toString() {
		        return String.format(
		                "Review [id=%s,user=%s, desc=%s, dateVisited=%s, visitAgain=%s]", id,
		                user, desc, dateVisited, visitAgain);
		    }

			
	}
